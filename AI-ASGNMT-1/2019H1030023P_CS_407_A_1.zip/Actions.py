'''
Name : Subhashis Dhar
Roll No: 2019H1030023P
'''

import enum

class Actions(enum.Enum):
    MU=1
    MD=2
    ML=3
    MR=4
    S=5
    N=6