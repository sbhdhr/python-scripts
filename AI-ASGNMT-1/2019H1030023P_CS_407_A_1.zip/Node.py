'''
Name : Subhashis Dhar
Roll No: 2019H1030023P
'''

class Node:
    def __init__(self,env,parent):
        self.env = env
        self.parent = parent